Shimosuwa Azami + Swan Bus merged GTFS. Stop coordinates updated from user-provided Shimosuwa GIS JSON. IDs are prefixed with AZAMI_ and SWAN_ where needed.
