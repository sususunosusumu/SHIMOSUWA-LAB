Merged GTFS v2. stop_lat/stop_lon are set only where real GIS JSON coordinates were matched. Unmatched fake coordinates are blank and hidden in the viewer.
