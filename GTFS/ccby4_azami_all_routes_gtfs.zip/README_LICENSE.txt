# あざみ号 全路線 GTFS

This package contains GTFS files generated from the timetable PDF.

## Creator
Shimosuwa Lab

## License
Creative Commons Attribution 4.0 International (CC BY 4.0)
https://creativecommons.org/licenses/by/4.0/

Recommended attribution:
GTFS data created by Shimosuwa Lab, licensed under CC BY 4.0.

## Notes
- Stop latitude/longitude values in these GTFS files may be provisional.
- Timetable data is based on the PDF provided in the ChatGPT conversation.
- Please verify the original source rights before public redistribution.
